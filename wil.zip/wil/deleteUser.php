<?php
include 'connect.php';
if(isset($_GET['studentID']))
{
   $student =$_GET['studentID'];
   
   $sql="delete from student where studentID = '$student'";
   $result = mysqli_query($con,$sql);
   if($result)
   {
   
   header('location:users.php');
   }
   else{
    die(mysqli_error($con));
   }
}
?>