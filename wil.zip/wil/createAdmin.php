<?php
session_start();
$adminU =0;
?>

<!doctype html>
<html lang="en">
  <head>

  <link rel="stylesheet" href="css/style.css">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

    <title>Testing</title>
</head>
  <body>
  <?php
  if($adminU){
  echo'<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Sorry </strong>Admin already exist
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
  }
?>


    <div class="container mt-5">

        <?php include('message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div style= "box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
                             transition: 0.3s;
                             border-radius: 5px;
                             margin-left: 350px;
                             background-color: skyblue;
                             width: 700px;

                             " class="card">
                    <div class="card-hearder">
                        <h4 style=" font-size: 20;
                                    font-family: Arial, Helvetica, sans-serif;"><i>Add Admin</i>
                            <a href="dashboard.php" class="btn btn-danger float-end">Back</a>
                            <a style="background-color: blue" href="indexx.php" class="btn btn-info float-end">View Admins</a>
                        </h4>
                    </div>
                    <div class="card-body">
                       <form action="code.php" method="POST">

                       <div class="mb-3">
                       <label>admin Id</label>
                         <input type="text" name="AdminID" class="form-control" required>
                       </div>
                       <div class="mb-3">
                       <label>Full Names</label>
                         <input type="text" name="Name" class="form-control" required>
                       </div>
                       <div class="mb-3">
                       <label>Surname</label>
                         <input type="text" name="Surname" class="form-control" required>
                       </div>
                       <label>Department</label>
                         <input type="text" name="Department" class="form-control" required>
                       </div>
                       <div class="mb-3">
                       <label>Email</label>
                         <input type="email" name="Email" class="form-control" required>
                       </div>
                       
                       <div class="mb-3">
                       <label>Password</label>
                         <input type="Password" name="password" class="form-control" required>
                       </div>
                       <div class="mb-3">
                            <button type="submit" name="save_admin" class="btn btn-primary">Add Admin</button>
                       </div>



                       </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
 

</body>
</html>