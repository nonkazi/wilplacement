<?php
	include 'connect.php'; 
	session_start();
	if (isset($_POST['approve'])){
		$id = $_POST['studentNumber'];

		
		$sql = "UPDATE application SET Status='1'  WHERE studentNumber = '$id'";
		$run = mysqli_query($con,$sql);
		if($run == true){
			
			echo "<script> 
					alert('Student Approved');
					window.open('users.php','_self');
				  </script>";
		}else{
			echo "<script> 
			alert('Failed To Approved');
			</script>";
		}
	}
	
 ?>
