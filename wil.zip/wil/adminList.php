<?php
    
    include 'connect.php';
    session_start();

?>



<!doctype html>
<html lang="en">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <title>Admin</title>
</head>
  <body>
  <h2 style="     
                          font-family: Arial, Helvetica, sans-serif;
                          font-size: 60px;
                          padding-top: 40px;
                          padding-left: 400px;
                          font-weight: 500;
                          color: darkblue;
                          float: left;"><i>List Of Admins</i></h2>  

<table style="
                                     font: white;
                                     background: skyblue;" class="table table-sm">

  

   

    <div class="row">
      <div class="col-md-12">
        
         
            
              <a href="createAdmin.php" class="btn btn-primary float-end">Add Admin</a>
            
          </div>
          <div class="card-body">
            <table class="table table-bothered table-triped">
              <thead>
                <tr>
                  <th>Admin Id</th>
                  <th>Full Names</th>
                  <th>Surname</th>
                  <th>Email</th>
                  
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                  $query = "select * from admin";
                  $query_run = mysqli_query($con, $query);

                  if(mysqli_num_rows($query_run) > 0)
                  {
                      foreach($query_run as $admin)
                      {
                        ?>
                            <tr>
                            <td><?= $admin['AdminID'];?></td>
                            <td><?= $admin['Name'];?></td>
                            <td><?= $admin['Surname'];?></td>
                            <td><?= $admin['Email'];?></td>
                            
                            <td>
                              <a href="admin-view.php?AdminID=<?=$admin['AdminID']; ?>" class="btn btn-info">View</a>
                              <form action="code.php" method="POST" class="d-inline">

                              
                              <button class ="btn btn-danger">
                                              <?php
                                                echo "<a onClick=\" javascript:return confirm('Are You sure to Delete this?'); \"
                                                href='deleteAdmin.php?AdminID={$admin['AdminID']}'>Delete</a>";
                                                ?>
                                 
                              </form>
                            </td>
                            </tr>
                        <?php
                      }
                  }
                  else
                  {
                      echo "<h5> No Record Found </h5>";
                  }
                ?>
            
              </tbody>
            </table>
            <a href="indexxAdmin.php" class="btn btn-primary">Back</a>
          </div>
        </div>
      </div>
    </div>
  </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
 

</body>
</html>