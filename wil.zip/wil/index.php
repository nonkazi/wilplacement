<?php


include 'connect.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
$studID = $_POST['studentNumber'];
$name=$_POST['Name'];
$surname=$_POST['Surname'];
$derpatment = $_POST['Department'];
$email=$_POST['StudentEmail'];
$password=$_POST['Password'];
$cpassword=$_POST['cpassword'];

// Handle the uploaded file
$targetDir = "records/";
$targetFile = $targetDir . basename($_FILES['AcademicRecord']['name']);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

move_uploaded_file($_FILES['AcademicRecord']['tmp_name'], $targetFile);
  


    $sql="insert into student(studentNumber,Name,Surname,StudentEmail,Department,AcademicRecord,Password)
    values('$studID','$name','$surname','$email','$derpatment','$targetFile','$pass')";
    

    $result=mysqli_query($con,$sql);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=, initial-scale=1.0">
  <title>Student Registration Page</title>

  <!--bootstrap css link-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
 rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi"
crossorigin="anonymous">


<!--font awesome link-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" 
integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
crossorigin="anonymous" referrerpolicy="no-referrer" />

<!--stylesheet-->
  
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php
if($user){
  echo'<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Ohh no Sorry </strong> User already exist
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';

}
?>

<?php
if($invalid){
  echo'<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Ohh no Sorry </strong> Password does not match!
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';

}
?>

<?php
if($success){
  echo'<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success </strong> You are successfully registered.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';

}
?>


<div class="container d-flex align-center justify-content-center">
  <div class="card">
    <!--haeder -->
<div class="card-header">
        <h3 class="text-center"><i>Register</i></h3>

</div>
    <!--card body -->

                 <div class="card-body">
                     <form action="index.php" method="POST">

                     <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control"
                placeholder="Enter your Student Number"
                required = "required"
                autocomplete="off"
                name= "studentNumber">
                  </div>
    
                     <!--first field  -->
                <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control"
                placeholder="Enter your First Name"
                required = "required"
                autocomplete="off"
                name= "Name">
                  </div>

                     
                
                     
                <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control"
                placeholder="Enter your Surname"
                required = "required"
                autocomplete="off"
                name= "Surname">
                  </div>

                        
                <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="email" class="form-control"
                placeholder="Enter your Student Email"
                required = "required"
                autocomplete="off"
                name= "StudentEmail">

                  </div>

                  <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control"
                placeholder="Enter your Department"
                required = "required"
                autocomplete="off"
                name= "Department">
                  </div>
                  <label for="floatingInput" >Upload Academic Record</label>
		<div class="form-floating mb-3">
		<input type="file"  name="AcademicRecord" 
        title="Upload "/>
       
		</div>
   

                       
           
                <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fas fa-key"></i></span>
                <input type="password" class="form-control"
                placeholder="Enter your Password"
                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
                title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required
                autocomplete="off"
                name= "Password" >
                  </div>

                              
           
                <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fas fa-key"></i></span>
                <input type="password" class="form-control"
                placeholder="Confirm Password"
                required = "required"
                autocomplete="off"
                name= "cpassword">
                  </div>

                            <!-- sign up button -->


                            <div class="form-group">
                              <input type="submit" name="register" value= "Register" class=" btn Signup">
                              
                            </div>
  
      </form>

    </div>

    <!--card footer -->
      <div class="card-footer text-center text-light sign up">

      Already registered? <a href="login.php">Log In</a>
      </div>

 
</div>

  </div>

</div>


</body>
</html>



