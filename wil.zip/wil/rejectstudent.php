<?php
	include 'connect.php'; 
	session_start();
	if (isset($_POST['reject'])){
		$id = $_POST['studentNumber'];
		
		$sql2= "select * from student where studentNumber = '$id'";
		$result2 = mysqli_query($con,$sql2);

		
		$sql = "UPDATE student SET Status='2' WHERE studentNumber = '$id'";

		$run = mysqli_query($con,$sql);
		
			
			echo "<script> 
					alert('Student Rejected');
					window.open('users.php','_self');
				  </script>";
		}else{
			echo "<script> 
			alert('Failed To Reject');
			</script>";
		}
	
	
 ?>
