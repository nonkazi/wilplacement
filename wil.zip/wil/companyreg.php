<?php
$success = 0;
$user = 0;
$invalid = 0;




include 'connect.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
$name = $_POST['companyName'];
$location=$_POST['Location'];
$person=$_POST['contactPerson'];
$email=$_POST['Email'];
$students=$_POST['noOfStudents'];




    $sql="insert into company(companyName,Location,contactPerson,Email,noOfStudents)
    values('$name','$location','$person','$email','$students')";
    
    $result=mysqli_query($con,$sql);
    if($result)
{
  echo "<script>alert('You have submitted your details successfully you will be contacted soon')</script>";
}

else {
        echo "<h2>Error</h2>";
        
    }
    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=, initial-scale=1.0">
  <title>Student Registration Page</title>

  <!--bootstrap css link-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
 rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi"
crossorigin="anonymous">


<!--font awesome link-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" 
integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
crossorigin="anonymous" referrerpolicy="no-referrer" />

<!--stylesheet-->
  
<link rel="stylesheet" href="css/style.css">
</head>
<body>


<div class="container d-flex align-center justify-content-center">
  <div class="card">
    <!--haeder -->
<div class="card-header">
        <h3 class="text-center"><i>Register</i></h3>

</div>
    <!--card body -->

                 <div class="card-body">
                     <form action="companyreg.php" method="POST">

                     <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control"
                placeholder="Enter Company Name"
                required = "required"
                autocomplete="off"
                name= "companyName">
                  </div>
    
                     <!--first field  -->
                <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control"
                placeholder="Enter Location"
                required = "required"
                autocomplete="off"
                name= "Location">
                  </div>

                     
                
                     
                <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control"
                placeholder="Enter Contact Person"
                required = "required"
                autocomplete="off"
                name= "contactPerson">
                  </div>

                        
                <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="email" class="form-control"
                placeholder="Enter Email"
                required = "required"
                autocomplete="off"
                name= "Email">

                  </div>

                  <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control"
                placeholder="Enter Number Of Students"
                required = "required"
                autocomplete="off"
                name= "noOfStudents">

                  </div>
    
           


                            <!-- sign up button -->


                            <div class="form-group">
                              <input type="submit" name="register" value= "Register" class=" btn Signup">
                              
                            </div>
  
      </form>

    </div>

  
 
</div>

  </div>

</div>


</body>
</html>



