<?php
$HOSTNAME='localhost';
$USERNAME='root';
$PASSWORD='';
$DATABASE='wildb';

$con =new mysqli($HOSTNAME,$USERNAME,$PASSWORD,$DATABASE);

if(!$con){
    
      die(mysqli_error($con));
}
?>