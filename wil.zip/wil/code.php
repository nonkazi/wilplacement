<?php
require 'connect.php';
session_start();
if(isset($_SESSION['Email']))
    {

	}
    $sql1 = "select * from admin  where Email = '".$_SESSION['Email']."'";
	$result1 =mysqli_query($con,$sql1);

	while($row1 = mysqli_fetch_array($result1)){
		$admin = $row1['AdminID'];
		
	 
		
	}



if(isset($_POST['delete_admin']))
{
    $admin_Id = mysqli_real_escape_string($con, $_POST['delete_admin']);

    $query = "DELETE FROM admin WHERE adminId='$admin_Id'";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Admin Deleted Successfully";
        header("Location:indexx.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Admin Not Deleted Successfully";
        header("Location:indexx.php");
        exit(0);
    }

}

if(isset($_POST['admin-view.php']))
{
    $admin_Id =  mysqli_real_escape_string($con, $_POST['AdminID']);
    $name = mysqli_real_escape_string($con, $_POST['Name']);
    $surname = mysqli_real_escape_string($con, $_POST['Surname']);
    $email = mysqli_real_escape_string($con, $_POST['Email']);
    $password = mysqli_real_escape_string($con, $_POST['Password']);

}


if(isset($_POST['save_admin']))
{
    
    $name = mysqli_real_escape_string($con, $_POST['Name']);
    $surname = mysqli_real_escape_string($con, $_POST['Surname']);
    $email = mysqli_real_escape_string($con, $_POST['Email']);
    
    $password = mysqli_real_escape_string($con, $_POST['Password']);
    $admin = mysqli_real_escape_string($con, $_POST['AdminID']);

    $sql="Select * from admin where 
Email='$email' OR AdminID = '$admin'";

$result=mysqli_query($con,$sql);
if($result){
  $num=mysqli_num_rows($result);
  if($num>0){
   
   $user = 1;

  }
   else{

    $result=mysqli_query($con,$sql);

    $query = "insert into admin (AdminID,Name,Surname,Email,Password) values
     ('$admin','$name','$surname','$email','$password')";

    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Admin Created Successfully";
        header("Location: adminList.php");
        exit(0);
    }
    else{
        $_SESSION['message'] = "Admin Not Created";
        header("Location: createAdmin.php");
        exit(0);
    }

}
}
}





if(isset($_POST['save_brand']))
{
   
    $brand = mysqli_real_escape_string($con, $_POST['brand']);
    $item = mysqli_real_escape_string($con, $_POST['item']);
    $value = mysqli_real_escape_string($con, $_POST['value']);
    
   
    $query = "insert into itembrand (brand,item,value,AdminID) values
     ('$brand','$item','$value','$admin')";

    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Brand added Successfully";
        header("Location: brand.php");
        exit(0);
    }
    else{
        $_SESSION['message'] = "Brand Not Added";
        header("Location: createBrand.php");
        exit(0);
    }
}
    


?>

