<?php
$login = 0;
$invalid = 0;

if($_SERVER['REQUEST_METHOD']=='POST'){

include 'connect.php';
$email=$_POST['Email'];
$password=$_POST['Password'];

$sql="Select * from admin where 
Email='$email'and Password='$password'";

$result=mysqli_query($con,$sql);
if($result){
  $num=mysqli_num_rows($result);
  if($num>0){
      $login = 1;
      session_start();
      $_SESSION['Email']=$email;
      header('location:indexxAdmin.php');
  }
    else{
      $invalid = 1;
        }
    
  }

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=, initial-scale=1.0">
  <title>Student Log In</title>

  <!--bootstrap css link-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
 rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi"
crossorigin="anonymous">


<!--font awesome link-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" 
integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
crossorigin="anonymous" referrerpolicy="no-referrer" />

<!--stylesheet-->
  
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php

if($login){
  echo'<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success </strong> You are successfully logged in.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';

   }
?>
<?php

if($invalid){
  echo'<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Error </strong> Invalid credintials.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';

   }
?>


<!--<h1>Welcome to MIT Leave Management system</h1>-->
<div class="container d-flex align-center justify-content-center" >
  <div class="card" >
    <!--haeder -->
<div class="card-header">
        <h3 class="text-center"><i>Admin Login</i></h3>

</div>
    <!--card body -->

                 <div class="card-body">
                     <form action="Adminlogin.php" method="post">
                      <!--first field  -->
                <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control"
                placeholder="Enter your Email"
                required = "required"
                autocomplete="off"
                name= "Email">
                  </div>

                            <!--second field   -->
           
                <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fas fa-key"></i></span>
                <input type="password" class="form-control"
                placeholder="Enter your password"
                required = "required"
                autocomplete="off"
                name= "Password">
                  </div>
                  

                            <!-- sign up button -->


                            <div class="form-group">
                              <input type="submit" name="register" value= "Login" class=" btn Signup">
                            </div>
  
      </form>

    </div>

    <!--card footer -->
      <div class="card-footer text-center text-light sign up">

      <a href="indexx.php">< <</a>
      </div>
          
  </div>

</div>


</body>
</html>



