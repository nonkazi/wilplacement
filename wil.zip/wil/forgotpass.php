<?php
$success = 0;
$user = 0;
$invalid = 0;

if($_SERVER['REQUEST_METHOD']=='POST'){

include 'connect.php';
$Email=$_POST['Email'];
$password=$_POST['password'];
$cpassword=$_POST['cpassword'];

$sql="Select * from student where 
StudentEmail='$Email'";


$result=mysqli_query($con,$sql);
if($result){
  $rows=mysqli_num_rows($result);
  
  
  if($rows==0){
    $user = 1;
   
  }
  else{
    if($password===$cpassword){

        $sql1="UPDATE student SET Password ='$password' WHERE Email='$Email'";
        $result1=mysqli_query($con,$sql1);
        $success = 1;
    }
    else{
        $invalid = 1;
       }

}
}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=, initial-scale=1.0">
  <title>Student Login</title>

  <!--bootstrap css link-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
 rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi"
crossorigin="anonymous">


<!--font awesome link-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" 
integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
crossorigin="anonymous" referrerpolicy="no-referrer" />

<!--stylesheet-->
  
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php
if($user){
  echo'<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Ohh no Sorry </strong> User does not exist
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';

}
?>

<?php
if($invalid){
  echo'<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Ohh no Sorry </strong> Password does not match!
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';

}
?>

<?php
if($success){
  echo'<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success </strong> You have successfully changed your password.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';

}
?>

<!--<h1>Welcome to MIT Leave Management system</h1>-->
<div class="container d-flex align-center justify-content-center" >
  <div class="card" >
    <!--haeder -->
<div class="card-header">
        <h3 class="text-center"><i>Change Password</i></h3>

</div>
    <!--card body -->

                 <div class="card-body">
                     <form action="forgotpass.php" method="post">
                      <!--first field  -->
                <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control"
                placeholder="Enter your email"
                required = "required"
                autocomplete="off"
                name= "Email">
                  </div>

                            <!--second field   -->
           
                <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fas fa-key"></i></span>
                <input type="password" class="form-control"
                placeholder="Enter your new password"
                required = "required"
                autocomplete="off"
                name= "password">
                  </div>

                  <div class="input-group mb-3">
                <span class="input-group-text"
                id="basic-addon1"><i class="fas fa-key"></i></span>
                <input type="password" class="form-control"
                placeholder="Confirm new password"
                required = "required"
                autocomplete="off"
                name= "cpassword">
                  </div>
                  

                            


                            <div class="form-group">
                              <input type="submit" name="register" value= "Submit" class=" btn Signup">
                            </div>
  
      </form>

    </div>

    <!--card footer -->
      <div class="card-footer text-center text-light sign up"> <a href="login.php">Go to Login</a>
      </div>

      <!-- <div class="card-footer text-center text-light sign up">
         <a href="forgotpass.php">Forgot Password</a>
      </div>-->