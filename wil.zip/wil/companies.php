<?php
   include 'connect.php';
   session_start();
	if(isset($_SESSION['Email']))
    {

	}
	


   ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=, initial-scale=1.0">
  <title>Admin Home Page</title>

  <!--bootstrap css link-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
 rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi"
crossorigin="anonymous">


<!--font awesome link-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" 
integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
crossorigin="anonymous" referrerpolicy="no-referrer" />

<!--stylesheet-->
  
<link rel="stylesheet" href="css/style.css">
</head>
<body>
    
    <!-- navbar-->
    
        
       
    <!--bootstrap js link-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
     integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" 
    crossorigin="anonymous"></script>
</body>

</html>



  <h2 style="     
                          font-family: Arial, Helvetica, sans-serif;
                          font-size: 60px;
                          padding-top: 40px;
                          padding-left: 400px;
                          font-weight: 500;
                          color: darkblue;
                          float: left;"><i>List Of Users</i></h2>  

<table style="
                                     font: white;
                                     background: skyblue;" class="table table-sm">

  

   

    <div class="row">
      <div class="col-md-12">
        
         
            
          </div>
          <div class="card-body">
            <table class="table table-bothered table-triped">
              <thead>
                <tr>
                  <th>Company ID</th>
                  <th>Company Name</th>
                  <th>Contact Person</th>
                  <th>Email</th>
                  <th>Location</th>
                  <th>Number of Students</th>
                 
                </tr>
              </thead>
              <tbody>
                <?php
                  $query = "select * from company";
                  $query_run = mysqli_query($con, $query);

                  if(mysqli_num_rows($query_run) > 0)
                  {
                      foreach($query_run as $row)
                      {
                        ?>
                            <tr>
                            <td><?= $row['companyID'];?></td>
                            <td><?= $row['companyName'];?></td>
                            <td><?= $row['contactPerson'];?></td>
                            <td><?= $row['Email'];?></td>
                            <td><?= $row['Location'];?></td>
                            <td><?= $row['noOfStudents'];?></td>
                            
                            
                    
                            </tr>
                        <?php
                      }
                  }
                  else
                  {
                      echo "<h5> No Record Found </h5>";
                  }
                ?>
            
              </tbody>
            </table>
            <a href="indexxAdmin.php" class="btn btn-primary">Back</a>
          </div>
        </div>
      </div>
    </div>
  </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
 

</body>
</html>