<?php
   include 'connect.php';
   session_start();
	if(isset($_SESSION['Email']))
    {

	}
	$sql1 = "select * from admin  where Email = '".$_SESSION['Email']."'";
	$result1 =mysqli_query($con,$sql1);

	while($row1 = mysqli_fetch_array($result1)){
		$name = $row1['Name'];
		$surname = $row1['Surname'];
	 
		
	}


	
	
   ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=, initial-scale=1.0">
  <title>Admin Home Page</title>

  <!--bootstrap css link-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
 rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi"
crossorigin="anonymous">


<!--font awesome link-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" 
integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
crossorigin="anonymous" referrerpolicy="no-referrer" />

<!--stylesheet-->
  
<link rel="stylesheet" href="css/style.css">
</head>
<body>
    
    <!-- navbar-->
    <div class="container-fluid p-0">
        <!--first child-->
    <nav class="navbar navbar-expand-lg navbar-light bg-danger">
    <div class="container-fluid">  
        <img scr ="../images/logo.png" alt="" class ="logo">
            <nav class="navbar navbar-expand-lg">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="" class="nav-link">welcome </a>
                    </li>
                </ul>

            </nav>
        </div>
    </nav>
    <!--second child-->
    <div class="bg-light">
        <h3 class="text-center p-2">Manage Details</h3>
    </div>

    <!--third child-->
    <div class="row">
        <div class="col-md-12 bg-secondary p-1">
            <div>
              <p class="text-light text-center"><?php echo "$name"?> <?php echo "$surname"?></P>  
            </div>
            <div class="button text-center">
                
                
                <button><a href="users.php" class="nav-link text-light bg-danger my-1">Students</a></button>
                <button><a href="approve.php" class="nav-link text-light bg-danger my-1">Approved Students</a></button>
                <button><a href="pending.php" class="nav-link text-light bg-danger my-1">Students Pending Approval</a></button>
                <button><a href="rejected.php" class="nav-link text-light bg-danger my-1">Rejected Students</a></button>
                <button><a href="companies.php" class="nav-link text-light bg-danger my-1">Companies</a></button>
                <button><a href="adminList.php" class="nav-link text-light bg-danger my-1">Admins</a></button>
                <button><a href="indexx.php" class="nav-link text-light bg-danger my-1">Log Out</a></button>
                
            </div>
        </div>
    </div>
</div>
    <!--bootstrap js link-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
     integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" 
    crossorigin="anonymous"></script>
</body>

</html>