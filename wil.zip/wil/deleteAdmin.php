<?php
include 'connect.php';
if(isset($_GET['AdminID']))
{
   $admin_Id =$_GET['AdminID'];
   
   $sql="delete from admin where AdminID = '$admin_Id'";
   $result = mysqli_query($con,$sql);
   if($result)
   {
   
   header('location:adminList.php');
   }
   else{
    die(mysqli_error($con));
   }
}
?>